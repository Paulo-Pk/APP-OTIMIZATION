using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using PCControlUltimate.App.Services;
using PCControlUltimate.App.ViewModels;
using PCControlUltimate.App.Views;
using PCControlUltimate.Core.Interfaces;
using PCControlUltimate.Gaming.Network;
using PCControlUltimate.Hardware;
using PCControlUltimate.Infrastructure.Data;
using PCControlUltimate.Infrastructure.Services;
using PCControlUltimate.Windows.Services;
using Serilog;

namespace PCControlUltimate.App;

public partial class App : Application
{
    private ServiceProvider? _serviceProvider;
    private PrivilegedAgentServer? _agentServer;
    private IHardwareMonitorService? _hardwareMonitor;
    private AgentClientService? _agentClient;
    private DatabaseService? _databaseService;
    private Mutex? _agentMutex;
    private bool _ownsAgentMutex;

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        string logDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "PCControlUltimate",
            "Logs"
        );
        Directory.CreateDirectory(logDir);

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.File(Path.Combine(logDir, "wpf_app.log"), rollingInterval: RollingInterval.Day)
            .CreateLogger();

        Log.Information("PC Control Ultimate v2.5.0 starting up...");

        ShutdownMode = ShutdownMode.OnMainWindowClose;
        DispatcherUnhandledException += (_, args) =>
        {
            Log.Error(args.Exception, "Unhandled UI dispatcher exception.");
            args.Handled = true;
        };

        try
        {
            _databaseService = new DatabaseService();
            try
            {
                await _databaseService.InitializeAndVerifyAsync();
            }
            catch (Exception dbEx)
            {
                Log.Warning(dbEx, "SQLite initialization warning; continuing startup.");
            }

            _hardwareMonitor = new LibreHardwareMonitorWrapper();
            try
            {
                await _hardwareMonitor.InitializeAsync();
            }
            catch (Exception hwEx)
            {
                Log.Warning(hwEx, "Hardware monitor initialization warning; continuing startup.");
            }

            // Single-instance check for the local Privileged Agent
            try
            {
                _agentMutex = new Mutex(true, @"Local\PCControlUltimate_PrivilegedAgent_Mutex_v25", out _ownsAgentMutex);
            }
            catch
            {
                _ownsAgentMutex = true;
            }

            var networkDiagnosticsService = new NetworkDiagnosticsService();
            string? inMemoryToken = null;
            if (_ownsAgentMutex)
            {
                try
                {
                    _agentServer = new PrivilegedAgentServer(_hardwareMonitor, PrivilegedAgentServer.DefaultPort, networkDiagnosticsService);
                    _agentServer.Start();
                    inMemoryToken = _agentServer.SessionToken;
                    Log.Information("PrivilegedAgentServer started on 127.0.0.1:{Port}", PrivilegedAgentServer.DefaultPort);
                }
                catch (Exception ex)
                {
                    Log.Warning(ex, "Could not bind PrivilegedAgentServer port; checking existing instance.");
                }
            }
            else
            {
                Log.Information("Existing PrivilegedAgentServer instance detected via Mutex; connecting via DPAPI token.");
            }

            _agentClient = new AgentClientService(inMemoryToken);

            var services = new ServiceCollection();
            services.AddSingleton(inMemoryToken ?? string.Empty);
            services.AddSingleton<LocalizationService>();
            services.AddSingleton<DatabaseService>(_databaseService);
            services.AddTransient<AppDbContext>(sp => sp.GetRequiredService<DatabaseService>().CreateDbContext());
            services.AddSingleton<IHardwareMonitorService>(_hardwareMonitor);
            services.AddSingleton<NetworkDiagnosticsService>(networkDiagnosticsService);
            services.AddSingleton<UniversalHardwareEngine>();
            services.AddSingleton<WindowsCompatibilityEngine>();
            services.AddSingleton<WingetSoftwareCenterService>();
            services.AddSingleton<PCControlUltimate.Diagnostics.SystemDoctorService>();
            services.AddSingleton<PCControlUltimate.Diagnostics.RecommendationEngine>();
            services.AddSingleton<AgentClientService>(_agentClient);
            services.AddSingleton<GameNetworkAcceleratorEngine>();
            services.AddSingleton<IAccelerationProvider>(sp => sp.GetRequiredService<GameNetworkAcceleratorEngine>());
            services.AddSingleton<IGameNetworkDetector>(sp => sp.GetRequiredService<GameNetworkAcceleratorEngine>());
            services.AddSingleton<IRouteProbe>(sp => sp.GetRequiredService<GameNetworkAcceleratorEngine>());
            services.AddSingleton<INetworkMeasurementService>(sp => sp.GetRequiredService<GameNetworkAcceleratorEngine>());
            services.AddSingleton<INodeHealthService>(sp => sp.GetRequiredService<GameNetworkAcceleratorEngine>());
            services.AddSingleton<ITunnelProvider>(sp => sp.GetRequiredService<GameNetworkAcceleratorEngine>());
            services.AddSingleton<ITrafficRoutingProvider>(sp => sp.GetRequiredService<GameNetworkAcceleratorEngine>());
            services.AddSingleton<MainViewModel>();
            services.AddSingleton<INavigationService>(sp => sp.GetRequiredService<MainViewModel>().Navigation);

            // Register all 17 Module ViewModels
            services.AddTransient<DashboardViewModel>();
            services.AddTransient<HardwareMonitorViewModel>();
            services.AddTransient<GpuHealthLabViewModel>();
            services.AddTransient<BoostCenterViewModel>();
            services.AddTransient<GameCenterViewModel>();
            services.AddTransient<GamingPresentMonViewModel>();
            services.AddTransient<BenchmarkCenterViewModel>();
            services.AddTransient<DiagnosticsViewModel>();
            services.AddTransient<RegistryOptimizerViewModel>();
            services.AddTransient<DebloatCleanerViewModel>();
            services.AddTransient<NetworkLabViewModel>();
            services.AddTransient<GameNetworkAcceleratorViewModel>();
            services.AddTransient<PeripheralTestViewModel>();
            services.AddTransient<DriverCenterViewModel>();
            services.AddTransient<SoftwareHubViewModel>();
            services.AddTransient<RestoreCenterViewModel>();
            services.AddTransient<AiAssistantViewModel>();

            // Register all 17 Module UserControl Views
            services.AddTransient<DashboardView>();
            services.AddTransient<HardwareMonitorView>();
            services.AddTransient<GpuHealthLabView>();
            services.AddTransient<BoostCenterView>();
            services.AddTransient<GameCenterView>();
            services.AddTransient<GamingPresentMonView>();
            services.AddTransient<BenchmarkCenterView>();
            services.AddTransient<DiagnosticsView>();
            services.AddTransient<RegistryOptimizerView>();
            services.AddTransient<DebloatCleanerView>();
            services.AddTransient<NetworkLabView>();
            services.AddTransient<GameNetworkAcceleratorView>();
            services.AddTransient<PeripheralTestView>();
            services.AddTransient<DriverCenterView>();
            services.AddTransient<SoftwareHubView>();
            services.AddTransient<RestoreCenterView>();
            services.AddTransient<AiAssistantView>();

            services.AddSingleton<MainWindow>();

            _serviceProvider = services.BuildServiceProvider();

            var mainWindow = _serviceProvider.GetRequiredService<MainWindow>();
            try
            {
                mainWindow.DataContext = _serviceProvider.GetRequiredService<MainViewModel>();
            }
            catch (Exception vmEx)
            {
                Log.Warning(vmEx, "Could not attach MainViewModel DataContext; continuing with WebView2 shell.");
            }
            MainWindow = mainWindow;
            mainWindow.Show();
            mainWindow.Activate();
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Critical error during application startup.");
            MessageBox.Show(
                $"Erro ao iniciar o PC Control Ultimate:\n\n{ex.Message}\n\nDetalhes foram gravados em {Path.Combine(logDir, "wpf_app.log")}",
                "PC Control Ultimate — Erro de Inicialização",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Shutdown(1);
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        Log.Information("PC Control Ultimate shutting down cleanly...");

        try
        {
            _hardwareMonitor?.StopPolling();
            _agentServer?.Stop();
            _agentServer?.Dispose();
            _agentClient?.Dispose();
            _hardwareMonitor?.Dispose();
            _serviceProvider?.Dispose();

            if (_ownsAgentMutex && _agentMutex != null)
            {
                _agentMutex.ReleaseMutex();
            }
            _agentMutex?.Dispose();
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Error while releasing application resources on exit.");
        }
        finally
        {
            Log.CloseAndFlush();
            base.OnExit(e);
        }
    }
}