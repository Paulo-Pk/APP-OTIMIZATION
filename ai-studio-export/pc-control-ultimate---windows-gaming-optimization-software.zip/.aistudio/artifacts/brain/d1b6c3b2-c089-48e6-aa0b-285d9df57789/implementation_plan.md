# PC Control Ultimate (`PCControlUltimate`) — Plano Revisado de Execução e Consolidação da Segunda Rodada (PR #10)

Este plano incorpora todas as exigências de revisão para consolidar os arquivos da branch `feature/trust-audit-first-pass` (PR #10) no **PC Control Ultimate**, garantindo paridade exata dos 23 ajustes entre `RegistryOptimizer.Catalog` (C#) e `defaultTweaks.ts` (TypeScript), eliminação de stubs em `scaffold_dotnet_solution.js`, validação explícita de `RegistryValueKind` em `InspectCatalogTweakCurrentState` e verificação transparente do ambiente Git/GitHub.

## Revisão Crítica do Workspace e Limitação de Publicação Direta

> [!IMPORTANT]
> **Diagnóstico Real do Workspace e da Integração GitHub**:
> 1. **Estado Atual do Workspace (`/app/applet`)**:
>    - `RegistryOptimizer.cs`, `MainViewModel.cs`, `MainWindow.xaml` e `RegistryOptimizerTests.cs` já contêm a maior parte das implementações da segunda rodada gravadas localmente no workspace do AI Studio.
>    - Contudo, a inspeção detalhada identificou **3 divergências locais** que serão corrigidas imediatamente após aprovação deste plano:
>      1. **`src/data/defaultTweaks.ts` divergente de `RegistryOptimizer.Catalog`**: `defaultTweaks.ts` continha ajustes legados (`gpu-tdr-level`, `stutter-dynamic-tick`, `input-mouse-accel`, `input-keyboard-delay`, `storage-ntfs-8dot3`, `visual-dwm-animations`) e `defaultOriginValue: '1'` em `mem-standby-clean`, em vez de refletir exatamente os **23 IDs reais** de `RegistryOptimizer.Catalog` (que incluem `priv-advertising-id` e `maint-startup-delay`, com `LargeSystemCache` tendo `defaultOriginValue: '0'`).
>      2. **`scripts/scaffold_dotnet_solution.js` com stubs antigos**: O script ainda continha versões ultrapassadas de `RegistryOptimizer.cs`, `DiskCleanerEngine.cs`, `RegistrySnapshotEngine.cs` e `MainWindow.xaml` que sobrescreveriam o código real caso executado.
>      3. **`InspectCatalogTweakCurrentState(string tweakId)`**: Além de delegar a `InspectCatalogTweak`, passará a conter validação explícita e direta de `ActualValueKind != def.ValueKind` retornando `"Tipo Incorreto"`, preservando `AccessDenied` e `ReadError` sem tocar no Registro.
> 2. **Transparência sobre Publicação no GitHub (`feature/trust-audit-first-pass`)**:
>    - O container Linux de execução do Google AI Studio (`/app/applet`) não possui diretório `.git`, credenciais SSH/PAT nem ferramenta de API/RPC para executar `git push` diretamente para `Paulo-Pk/APP-OTIMIZATION`.
>    - Conforme a instrução *"Se a integração não permitir publicar diretamente na branch existente, interrompa e informe a limitação. Não tente contornar com uma publicação em outra branch"*, após aplicarmos e validarmos 100% das alterações nos arquivos do workspace, apresentaremos o diff completo e informaremos explicitamente que o envio do commit para `feature/trust-audit-first-pass` requer o botão nativo **Sync / Save to GitHub** da interface do Google AI Studio pelo proprietário da conta.

---

## 1. Escopo Exato de Implementação e Sincronização

1. **`src/PCControlUltimate.Windows/Services/RegistryOptimizer.cs`**:
   - Em `InspectCatalogTweakCurrentState(string tweakId, IRegistryKeyProbe? probe = null)`: validar explicitamente `readResult.ActualValueKind != def.ValueKind` (via `GetValueKind` no probe) e retornar `"Tipo Incorreto"`, nunca classificando tipo incompatível como `"Ativo"` ou `"Inativo"`.
   - Preservar os 8 estados de `TweakInspectionState` (`Active`, `Inactive`, `Custom`, `NotConfigured`, `AccessDenied`, `WrongType`, `Incompatible`, `ReadError`), `IsUndeterminable = true` para `AccessDenied`/`ReadError`/`Incompatible` (`"Estado Não Determinável"`), e as 4 categorias de `TweakDefaultBehaviorKind` (`KnownDocumentedValue`, `AbsentWithKnownDefault`, `EditionOrConfigDependent`, `UndeterminedWhenAbsent`).
   - Preservar integralmente `RegistryStateLedger` (DPAPI + HMAC-SHA256) e todas as proteções de restauração.

2. **`src/PCControlUltimate.App/ViewModels/MainViewModel.cs` & `src/PCControlUltimate.App/MainWindow.xaml`**:
   - Garantir **1 única consulta** por ajuste no construtor de `MainViewModel` (`var initialReport = RegistryOptimizer.InspectCatalogTweak(def.TweakId)`).
   - Garantir o botão `ATUALIZAR ESTADOS` (`REFRESH STATES`) com `RefreshTweakStatesCommand` -> `RefreshAllTweakStatesAsync()`, bloqueio de clique concorrente (`CanRefreshTweakStates`), texto dinâmico (`CONSULTANDO REGISTRO...` / `QUERYING REGISTRY...`) e resumo completo em `StatusMessage`.

3. **`src/data/defaultTweaks.ts`**:
   - Sincronizar exatamente os **23 ajustes** e seus `TweakId`s reais presentes em `RegistryOptimizer.Catalog`, removendo entradas antigas ou divergentes e alinhando `defaultOriginValue`, `targetRawValue`, `valueKind`, `requiresReboot`, `recommendationStatus` e descrições auditadas (incluindo `DisablePagingExecutive` sem requisito arbitrário de 16 GB, `LargeSystemCache` com `defaultOriginValue = '0'` e `TcpMaxDataRetransmissions` com `defaultOriginValue = '5'`).

4. **`scripts/scaffold_dotnet_solution.js`**:
   - Remover os blocos que sobrescreviam `RegistryOptimizer.cs`, `DiskCleanerEngine.cs`, `RegistrySnapshotEngine.cs` e `MainWindow.xaml` com stubs simplificados, preservando os arquivos reais caso o script seja invocado.

5. **`tests/PCControlUltimate.Tests/RegistryOptimizerTests.cs`**:
   - Garantir testes cobrindo:
     - `DWORD` esperado e encontrado (`Ativo` / `Inativo`).
     - `DWORD` esperado, mas encontrado como `REG_SZ` (`WrongType` / `"Tipo Incorreto"` tanto em `InspectCatalogTweak` quanto em `InspectCatalogTweakCurrentState`).
     - As classificações de ausência (`AbsentWithKnownDefault`, `EditionOrConfigDependent`, `UndeterminedWhenAbsent`).
     - `AccessDenied`, `ReadError` e `Incompatible` classificados como `"Estado Não Determinável"` (`IsUndeterminable = true`).
     - Imutabilidade do Registro durante inspeção (`WriteCount == 0 && DeleteCount == 0`).
     - Atualização de estados após alteração manual externa no Registro.
     - Correspondência exata dos 23 IDs do catálogo.

---

## 2. Catálogo Real de 23 Ajustes (100% Sincronizado entre C# e TypeScript)

| # | `TweakId` Real em `RegistryOptimizer.Catalog` | Nome Técnico Auditado (PT-BR) | Chave e Valor no Registro | Tipo | Recomendado | Referência (`DefaultOriginValue`) | Comportamento na Ausência |
| :- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `perf-mmcss` | Reserva de CPU do Agendador Multimídia (MMCSS SystemResponsiveness) | `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile` (`SystemResponsiveness`) | `DWord` | `10` | `20` | `KnownDocumentedValue` |
| 2 | `perf-game-dvr` | Captura em Segundo Plano do Xbox Game DVR (GameDVR_Enabled) | `HKCU\System\GameConfigStore` (`GameDVR_Enabled`) | `DWord` | `0` | `1` | `EditionOrConfigDependent` |
| 3 | `perf-hpet` | Prioridade e Quantum de Processos em Primeiro Plano (Win32PrioritySeparation) | `HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl` (`Win32PrioritySeparation`) | `DWord` | `38` | `2` | `KnownDocumentedValue` |
| 4 | `perf-tcp-nagle` | Controle de Limitação de Rede Multimídia (NetworkThrottlingIndex) | `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile` (`NetworkThrottlingIndex`) | `DWord` | `-1` | `10` | `KnownDocumentedValue` |
| 5 | `start-fast-boot` | Desativar Inicialização Rápida do Windows (Fast Startup / HiberbootEnabled = 0) | `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power` (`HiberbootEnabled`) | `DWord` | `0` | `1` | `EditionOrConfigDependent` |
| 6 | `start-edge-preload` | Impulso de Inicialização do Microsoft Edge (StartupBoostEnabled) | `HKLM\SOFTWARE\Policies\Microsoft\Edge` (`StartupBoostEnabled`) | `DWord` | `0` | `1` | `EditionOrConfigDependent` |
| 7 | `bg-telemetry` | Política de Dados de Diagnóstico do Windows (AllowTelemetry) | `HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection` (`AllowTelemetry`) | `DWord` | `1` | `3` | `EditionOrConfigDependent` |
| 8 | `bg-cortana-news` | Feed de Notícias e Interesses da Barra de Tarefas (Windows 10) | `HKCU\Software\Microsoft\Windows\CurrentVersion\Feeds` (`ShellFeedsTaskbarViewMode`) | `DWord` | `2` | `0` | `EditionOrConfigDependent` (Build <= 21999) |
| 9 | `power-ultimate-plan` | Controle de Power Throttling de Processos (PowerThrottlingOff) | `HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling` (`PowerThrottlingOff`) | `DWord` | `1` | `0` | `AbsentWithKnownDefault` |
| 10 | `power-pcie-link` | Categoria de Agendamento Multimídia para Jogos (MMCSS Scheduling Category) | `HKLM\...\Multimedia\SystemProfile\Tasks\Games` (`Scheduling Category`) | `String` | `High` | `Medium` | `KnownDocumentedValue` |
| 11 | `serv-sysmain` | Modo de Inicialização do Serviço SysMain / Superfetch (Start) | `HKLM\SYSTEM\CurrentControlSet\Services\SysMain` (`Start`) | `DWord` | `3` | `2` | `KnownDocumentedValue` |
| 12 | `serv-spooler` | Modo de Inicialização do Spooler de Impressão (Spooler Start) | `HKLM\SYSTEM\CurrentControlSet\Services\Spooler` (`Start`) | `DWord` | `3` | `2` | `KnownDocumentedValue` |
| 13 | `mem-standby-clean` | Configuração do Cache de Sistema de Arquivos (LargeSystemCache) | `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management` (`LargeSystemCache`) | `DWord` | `0` | `0` | `KnownDocumentedValue` |
| 14 | `mem-lock-executive` | Retenção do Executivo do Kernel em RAM (DisablePagingExecutive) | `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management` (`DisablePagingExecutive`) | `DWord` | `1` | `0` | `KnownDocumentedValue` |
| 15 | `game-hags` | Agendamento de GPU Acelerado por Hardware (HAGS / HwSchMode) | `HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers` (`HwSchMode`) | `DWord` | `2` | `1` | `EditionOrConfigDependent` |
| 16 | `game-fso-override` | Política de Comportamento de Tela Inteira (GameDVR_FSEBehaviorMode) | `HKCU\System\GameConfigStore` (`GameDVR_FSEBehaviorMode`) | `DWord` | `2` | `0` | `EditionOrConfigDependent` |
| 17 | `perf-fso-flags` | Flag Auxiliar de Comportamento Fullscreen (GameDVR_FSEBehavior) | `HKCU\System\GameConfigStore` (`GameDVR_FSEBehavior`) | `DWord` | `2` | `0` | `UndeterminedWhenAbsent` |
| 18 | `sys-delivery-p2p` | Modo de Download da Otimização de Entrega (DODownloadMode) | `HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization` (`DODownloadMode`) | `DWord` | `0` | `1` | `EditionOrConfigDependent` |
| 19 | `sys-transparency` | Efeitos de Transparência do Windows (EnableTransparency) | `HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize` (`EnableTransparency`) | `DWord` | `0` | `1` | `KnownDocumentedValue` |
| 20 | `storage-ntfs-lastaccess` | Atualização de Timestamp de Último Acesso NTFS (NtfsDisableLastAccessUpdate) | `HKLM\SYSTEM\CurrentControlSet\Control\FileSystem` (`NtfsDisableLastAccessUpdate`) | `DWord` | `1` | `0` | `EditionOrConfigDependent` |
| 21 | `net-tcp-autotuning` | Limite de Retransmissões de Dados TCP (TcpMaxDataRetransmissions) | `HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters` (`TcpMaxDataRetransmissions`) | `DWord` | `5` | `5` | `AbsentWithKnownDefault` |
| 22 | `priv-advertising-id` | Identificador de Anúncios do Usuário (Advertising ID) | `HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo` (`Enabled`) | `DWord` | `0` | `1` | `EditionOrConfigDependent` |
| 23 | `maint-startup-delay` | Atraso de Inicialização de Aplicativos do Explorer (StartupDelayInMSec) | `HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Serialize` (`StartupDelayInMSec`) | `DWord` | `0` | `1000` | `UndeterminedWhenAbsent` |

---

## 3. Arquitetura de Validação e Sincronização

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                     Camada C# (PCControlUltimate.Windows / App)              │
│  • RegistryOptimizer.Catalog (23 TweakIds exatos)                            │
│  • InspectCatalogTweak & InspectCatalogTweakCurrentState:                    │
│      - GetValueKind / ActualValueKind != def.ValueKind -> "Tipo Incorreto"   │
│      - AccessDenied / ReadError / Incompatible -> "Estado Não Determinável"  │
│      - Ausência Tripla via TweakDefaultBehaviorKind                          │
│  • MainViewModel:                                                            │
│      - Inicialização com 1 única consulta por ajuste                         │
│      - RefreshTweakStatesCommand (assíncrono + CanRefreshTweakStates)        │
└───────────────────────────────────────┬──────────────────────────────────────┘
                                        │ Paridade 1:1 (23 IDs)
                                        ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                     Camada TypeScript & Scripts Auxiliares                   │
│  • src/data/defaultTweaks.ts:                                                │
│      - Exatamente os mesmos 23 TweakIds, chaves, tipos e valores             │
│  • scripts/scaffold_dotnet_solution.js:                                      │
│      - Stubs antigos removidos (nunca sobrescreve arquivos reais existentes) │
└──────────────────────────────────────────────────────────────────────────────┘
```
