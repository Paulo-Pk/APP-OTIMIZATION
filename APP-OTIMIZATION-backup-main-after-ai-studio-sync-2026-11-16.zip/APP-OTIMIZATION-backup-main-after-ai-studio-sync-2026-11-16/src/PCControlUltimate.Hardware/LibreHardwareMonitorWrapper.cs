using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using LibreHardwareMonitor.Hardware;
using PCControlUltimate.Core.Interfaces;
using PCControlUltimate.Core.Models;

namespace PCControlUltimate.Hardware;

public class LibreHardwareMonitorWrapper : IHardwareMonitorService
{
    private readonly Computer _computer;
    private Timer? _pollingTimer;
    private readonly SemaphoreSlim _captureLock = new(1, 1);
    private readonly object _pollingLock = new();
    private volatile bool _disposed;

    public bool IsAvailable { get; private set; }
    public SensorReadingStatus CurrentStatus { get; private set; } = SensorReadingStatus.ReadingUnavailable;
    public string? LastCommunicationError { get; private set; }
    public event EventHandler<HardwareSnapshot>? TelemetryUpdated;

    public LibreHardwareMonitorWrapper()
    {
        _computer = new Computer
        {
            IsCpuEnabled = true,
            IsGpuEnabled = true,
            IsMemoryEnabled = true,
            IsMotherboardEnabled = true,
            IsStorageEnabled = true,
            IsNetworkEnabled = false
        };
    }

    internal static bool IsSystemDrive(string? driveName, string? systemDrive)
    {
        if (string.IsNullOrWhiteSpace(driveName) || string.IsNullOrWhiteSpace(systemDrive))
            return false;

        return string.Equals(
            driveName.Trim().TrimEnd('\\'),
            systemDrive.Trim().TrimEnd('\\'),
            StringComparison.OrdinalIgnoreCase);
    }

    public Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _captureLock.Wait(cancellationToken);
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (_disposed) throw new ObjectDisposedException(nameof(LibreHardwareMonitorWrapper));
            if (!OperatingSystem.IsWindows())
            {
                IsAvailable = false;
                CurrentStatus = SensorReadingStatus.SensorNotSupported;
                LastCommunicationError = "Leitura física via LibreHardwareMonitor requer sistema operacional Windows nativo.";
                return Task.CompletedTask;
            }

            try
            {
                _computer.Open();
                IsAvailable = true;
                CurrentStatus = SensorReadingStatus.Available;
                LastCommunicationError = null;
            }
            catch (Exception ex)
            {
                IsAvailable = false;
                CurrentStatus = SensorReadingStatus.CommunicationFailure;
                LastCommunicationError = $"Falha ao inicializar sensores de hardware (verifique elevação UAC): {ex.Message}";
            }
            return Task.CompletedTask;
        }
        finally
        {
            _captureLock.Release();
        }
    }

    public async Task<HardwareSnapshot> CaptureSnapshotAsync()
    {
        await _captureLock.WaitAsync().ConfigureAwait(false);
        try
        {
            return await CaptureSnapshotCoreAsync().ConfigureAwait(false);
        }
        finally
        {
            _captureLock.Release();
        }
    }

    private Task<HardwareSnapshot> CaptureSnapshotCoreAsync()
    {
        if (_disposed)
        {
            return Task.FromResult(new HardwareSnapshot(
                DateTime.UtcNow,
                null, null, null, null, null, null, null, null,
                Array.Empty<SensorDataPoint>(),
                MonitorStatus: SensorReadingStatus.CommunicationFailure,
                DiagnosticMessage: "Serviço de monitoramento encerrado (Disposed)."
            ));
        }

        if (!IsAvailable)
        {
            return Task.FromResult(new HardwareSnapshot(
                DateTime.UtcNow,
                null, null, null, null, null, null, null, null,
                Array.Empty<SensorDataPoint>(),
                MonitorStatus: CurrentStatus,
                DiagnosticMessage: LastCommunicationError ?? "Sensores de hardware indisponíveis."
            ));
        }

        // Clear transient read errors before each fresh sample so a recovered sensor
        // does not leave the entire monitor permanently marked as failed.
        CurrentStatus = SensorReadingStatus.Available;
        LastCommunicationError = null;

        string? cpuModel = null;
        float? cpuTemp = null;
        int cpuTempPriority = 0;
        float? cpuLoad = null;
        float? cpuClock = null;
        float? cpuClockFallback = null;
        float? cpuPower = null;

        string? gpuModel = null;
        float? gpuTemp = null;
        float? gpuHotspot = null;
        float? gpuLoad = null;
        float? gpuClock = null;
        float? gpuPower = null;
        float? gpuFanRpm = null;
        float? gpuVramUsed = null;
        float? gpuVramTotal = null;

        float? ramUsed = null;
        float? ramAvailable = null;
        float? ramTotal = null;

        var sensorList = new List<SensorDataPoint>();
        var storageDrives = new List<StorageTelemetryPoint>();
        var gpuAdapters = new List<GpuAdapterTelemetryPoint>();

        try
        {
            // Order hardware so discrete GPUs are listed before integrated GPUs without favoring any specific vendor/model
            var orderedHardware = new List<IHardware>();
            foreach (var rootHardware in _computer.Hardware)
                AddHardwareTree(rootHardware, orderedHardware);
            orderedHardware.Sort((a, b) => GetHardwarePriorityScore(b).CompareTo(GetHardwarePriorityScore(a)));

            foreach (var hardware in orderedHardware)
            {
                try
                {
                    hardware.Update();
                }
                catch (Exception hwEx)
                {
                    sensorList.Add(new SensorDataPoint(
                        $"{hardware.Identifier}/comm-error",
                        $"{hardware.Name} (Erro de leitura)",
                        hardware.HardwareType.ToString(),
                        "Diagnostic",
                        null,
                        string.Empty,
                        false,
                        SensorReadingStatus.CommunicationFailure
                    ));
                    CurrentStatus = SensorReadingStatus.CommunicationFailure;
                    LastCommunicationError = $"Falha ao atualizar '{hardware.Name}': {hwEx.Message}";
                    continue;
                }

                bool isGpuHardware = hardware.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel;
                bool isPrimaryGpuCandidate = false;

                if (hardware.HardwareType == HardwareType.Cpu && string.IsNullOrWhiteSpace(cpuModel))
                {
                    cpuModel = hardware.Name;
                }
                else if (isGpuHardware && string.IsNullOrWhiteSpace(gpuModel))
                {
                    gpuModel = hardware.Name;
                    isPrimaryGpuCandidate = true;
                }

                float? driveTemp = null;
                float? adapterCoreTemp = null;
                float? adapterHotspot = null;
                float? adapterLoad = null;
                float? adapterClock = null;
                float? adapterPower = null;
                float? adapterFanRpm = null;
                float? adapterVramUsed = null;
                float? adapterVramTotal = null;
                float? adapterDedicatedVramUsed = null;
                float? adapterDedicatedVramTotal = null;

                foreach (var sensor in hardware.Sensors)
                {
                    bool hasValidReading = sensor.Value.HasValue && !float.IsNaN(sensor.Value.Value) && !float.IsInfinity(sensor.Value.Value);
                    var status = hasValidReading
                        ? SensorReadingStatus.Available
                        : SensorReadingStatus.ReadingUnavailable;

                    var point = new SensorDataPoint(
                        sensor.Identifier.ToString(),
                        sensor.Name,
                        hardware.HardwareType.ToString(),
                        sensor.SensorType.ToString(),
                        hasValidReading ? sensor.Value : null,
                        sensor.SensorType switch
                        {
                            SensorType.Temperature => "°C",
                            SensorType.Load => "%",
                            SensorType.Clock => "MHz",
                            SensorType.Voltage => "V",
                            SensorType.Power => "W",
                            SensorType.Fan => "RPM",
                            _ => string.Empty
                        },
                        hasValidReading,
                        status
                    );
                    sensorList.Add(point);

                    if (!hasValidReading) continue;

                    if (hardware.HardwareType == HardwareType.Cpu)
                    {
                        if (sensor.SensorType == SensorType.Temperature && sensor.Value is > 0)
                        {
                            int candidatePriority = GetCpuTemperatureSensorPriority(sensor.Name);
                            if (cpuTemp is null || candidatePriority > cpuTempPriority)
                            {
                                cpuTemp = sensor.Value;
                                cpuTempPriority = candidatePriority;
                            }
                        }
                        if (sensor.SensorType == SensorType.Load && sensor.Name.Contains("Total", StringComparison.OrdinalIgnoreCase))
                            cpuLoad ??= sensor.Value;
                        if (sensor.SensorType == SensorType.Clock && sensor.Value is > 0)
                        {
                            // Ignore zero-MHz readings from sleeping cores and report the fastest
                            // currently active core instead of freezing on the first core sensor.
                            cpuClockFallback = Math.Max(cpuClockFallback ?? 0, sensor.Value.Value);
                            if (sensor.Name.Contains("Core", StringComparison.OrdinalIgnoreCase))
                                cpuClock = Math.Max(cpuClock ?? 0, sensor.Value.Value);
                        }
                        if (sensor.SensorType == SensorType.Power &&
                            (sensor.Name.Contains("Package", StringComparison.OrdinalIgnoreCase) ||
                             sensor.Name.Contains("Cores", StringComparison.OrdinalIgnoreCase)))
                        {
                            cpuPower ??= sensor.Value;
                        }
                    }
                    else if (isGpuHardware)
                    {
                        if (sensor.SensorType == SensorType.Temperature)
                        {
                            if (sensor.Name.Contains("Hot Spot", StringComparison.OrdinalIgnoreCase) ||
                                sensor.Name.Contains("Hotspot", StringComparison.OrdinalIgnoreCase) ||
                                sensor.Name.Contains("Junction", StringComparison.OrdinalIgnoreCase))
                            {
                                adapterHotspot ??= sensor.Value;
                            }
                            else if ((sensor.Name.Contains("Core", StringComparison.OrdinalIgnoreCase) ||
                                      sensor.Name.Equals("GPU", StringComparison.OrdinalIgnoreCase) ||
                                      sensor.Name.Equals("GPU Temperature", StringComparison.OrdinalIgnoreCase)) &&
                                     !sensor.Name.Contains("Memory", StringComparison.OrdinalIgnoreCase) &&
                                     !sensor.Name.Contains("SoC", StringComparison.OrdinalIgnoreCase))
                            {
                                adapterCoreTemp ??= sensor.Value;
                            }
                        }
                        if (sensor.SensorType == SensorType.Load && sensor.Name.Contains("Core", StringComparison.OrdinalIgnoreCase))
                            adapterLoad ??= sensor.Value;
                        if (sensor.SensorType == SensorType.Clock && sensor.Name.Contains("Core", StringComparison.OrdinalIgnoreCase))
                            adapterClock ??= sensor.Value;
                        if (sensor.SensorType == SensorType.Power)
                            adapterPower ??= sensor.Value;
                        if (sensor.SensorType == SensorType.Fan)
                            adapterFanRpm ??= sensor.Value;
                        // Only the GPU's dedicated-memory sensors represent VRAM.
                        // "D3D Shared Memory" is backed by system RAM and must never be
                        // merged into the dedicated VRAM figures.
                        if (sensor.SensorType == SensorType.SmallData &&
                            sensor.Name.Equals("GPU Memory Used", StringComparison.OrdinalIgnoreCase))
                            adapterVramUsed ??= sensor.Value;
                        if (sensor.SensorType == SensorType.SmallData &&
                            sensor.Name.Equals("GPU Memory Total", StringComparison.OrdinalIgnoreCase))
                            adapterVramTotal ??= sensor.Value;

                        // Some drivers expose dedicated VRAM only through the D3D counters.
                        // Keep these as a fallback, but intentionally ignore D3D Shared Memory.
                        if (sensor.SensorType == SensorType.SmallData &&
                            sensor.Name.Equals("D3D Dedicated Memory Used", StringComparison.OrdinalIgnoreCase))
                            adapterDedicatedVramUsed ??= sensor.Value;
                        if (sensor.SensorType == SensorType.SmallData &&
                            sensor.Name.Equals("D3D Dedicated Memory Total", StringComparison.OrdinalIgnoreCase))
                            adapterDedicatedVramTotal ??= sensor.Value;

                        if (isPrimaryGpuCandidate)
                        {
                            gpuTemp ??= adapterCoreTemp;
                            gpuHotspot ??= adapterHotspot;
                            gpuLoad ??= adapterLoad;
                            gpuClock ??= adapterClock;
                            gpuPower ??= adapterPower;
                            gpuFanRpm ??= adapterFanRpm;
                            gpuVramUsed ??= adapterVramUsed;
                            gpuVramTotal ??= adapterVramTotal;
                        }
                    }
                    else if (hardware.HardwareType == HardwareType.Memory &&
                             hardware.Name.Equals("Total Memory", StringComparison.OrdinalIgnoreCase) &&
                             hardware.Identifier.ToString().Equals("/ram", StringComparison.OrdinalIgnoreCase))
                    {
                        // LibreHardwareMonitor also reports "Virtual Memory" as HardwareType.Memory
                        // (with a /vram identifier). That is the page file, not physical RAM or GPU VRAM.
                        // Only the /ram hardware node is allowed to populate system RAM telemetry.
                        if (sensor.SensorType == SensorType.Data && sensor.Name.Equals("Memory Used", StringComparison.OrdinalIgnoreCase))
                            ramUsed ??= sensor.Value;
                        if (sensor.SensorType == SensorType.Data && sensor.Name.Equals("Memory Available", StringComparison.OrdinalIgnoreCase))
                            ramAvailable ??= sensor.Value;
                    }
                    else if (hardware.HardwareType == HardwareType.Storage)
                    {
                        if (sensor.SensorType == SensorType.Temperature)
                            driveTemp ??= sensor.Value;
                    }
                }

                if (isGpuHardware)
                {
                    adapterVramUsed ??= adapterDedicatedVramUsed;
                    adapterVramTotal ??= adapterDedicatedVramTotal;

                    gpuAdapters.Add(new GpuAdapterTelemetryPoint(
                        Model: hardware.Name,
                        HardwareType: hardware.HardwareType.ToString(),
                        CoreTempC: adapterCoreTemp,
                        HotspotTempC: adapterHotspot,
                        LoadPercent: adapterLoad,
                        CoreClockMhz: adapterClock,
                        PowerWatts: adapterPower,
                        FanRpm: adapterFanRpm,
                        VramUsedMb: adapterVramUsed,
                        VramTotalMb: adapterVramTotal,
                        DriverVersion: null,
                        PnpDeviceId: hardware.Identifier.ToString(),
                        SensorIdentifier: hardware.Identifier.ToString()
                    ));
                }

                if (hardware.HardwareType == HardwareType.Storage)
                {
                    storageDrives.Add(new StorageTelemetryPoint(
                        Model: hardware.Name,
                        CapacityGb: null,
                        FreeSpaceGb: null,
                        TemperatureC: driveTemp
                    ));
                }
            }
        }
        catch (Exception ex)
        {
            CurrentStatus = SensorReadingStatus.CommunicationFailure;
            LastCommunicationError = $"Erro de comunicação ao ler sensores: {ex.Message}";
        }

        // Explicitly record SensorNotSupported if GPU is present but Hotspot sensor is not exposed by the hardware
        if (!string.IsNullOrWhiteSpace(gpuModel) && !gpuHotspot.HasValue)
        {
            sensorList.Add(new SensorDataPoint(
                "/gpu/hotspot-unsupported",
                "GPU Hot Spot",
                "Gpu",
                "Temperature",
                null,
                "°C",
                false,
                SensorReadingStatus.SensorNotSupported
            ));
        }

        // Also append logical fixed volumes: physical drive sensors do not expose mount-point capacity.
        try
        {
            foreach (var drive in DriveInfo.GetDrives())
            {
                if (drive.IsReady && drive.DriveType == DriveType.Fixed)
                {
                    float totalGb = (float)Math.Round(drive.TotalSize / (1024.0 * 1024.0 * 1024.0), 1);
                    float freeGb = (float)Math.Round(drive.AvailableFreeSpace / (1024.0 * 1024.0 * 1024.0), 1);
                    string label = string.IsNullOrWhiteSpace(drive.VolumeLabel) ? "Sem rótulo" : drive.VolumeLabel;
                    storageDrives.Add(new StorageTelemetryPoint(
                        Model: $"Volume {drive.Name.TrimEnd('\\')} — {label}",
                        CapacityGb: totalGb,
                        FreeSpaceGb: freeGb,
                        TemperatureC: null,
                        IsSystemDisk: IsSystemDrive(drive.Name, Environment.GetEnvironmentVariable("SystemDrive"))
                    ));
                }
            }
        }
        catch { }

        if (ramUsed.HasValue && ramAvailable.HasValue)
            ramTotal = ramUsed.Value + ramAvailable.Value;

        // Keep the legacy top-level GPU VRAM fields consistent with the selected
        // primary adapter, including when only the D3D dedicated-memory fallback exists.
        var primaryGpuTelemetry = gpuAdapters.FirstOrDefault(adapter =>
            string.Equals(adapter.Model, gpuModel, StringComparison.OrdinalIgnoreCase));
        gpuVramUsed ??= primaryGpuTelemetry?.VramUsedMb;
        gpuVramTotal ??= primaryGpuTelemetry?.VramTotalMb;

        cpuClock ??= cpuClockFallback;

        var snapshot = new HardwareSnapshot(
            DateTime.UtcNow,
            cpuTemp,
            cpuLoad,
            gpuTemp,
            gpuHotspot,
            gpuVramUsed,
            gpuVramTotal,
            ramUsed,
            ramTotal,
            sensorList,
            cpuModel,
            cpuClock,
            cpuPower,
            gpuModel,
            gpuLoad,
            gpuClock,
            gpuPower,
            gpuFanRpm,
            storageDrives,
            CurrentStatus,
            LastCommunicationError,
            gpuAdapters
        );

        return Task.FromResult(snapshot);
    }

    public void StartPolling(TimeSpan interval)
    {
        if (interval <= TimeSpan.Zero)
            throw new ArgumentOutOfRangeException(nameof(interval), "O intervalo de telemetria deve ser maior que zero.");

        lock (_pollingLock)
        {
            if (_disposed) return;

            _pollingTimer?.Dispose();
            _pollingTimer = new Timer(async _ =>
            {
                if (_disposed) return;
                try
                {
                    var snap = await CaptureSnapshotAsync().ConfigureAwait(false);
                    if (!_disposed)
                        TelemetryUpdated?.Invoke(this, snap);
                }
                catch (ObjectDisposedException)
                {
                    // Shutdown may race with a scheduled timer callback.
                }
                catch (Exception ex)
                {
                    if (!_disposed)
                    {
                        LastCommunicationError = $"Falha inesperada no ciclo de telemetria: {ex.Message}";
                        CurrentStatus = SensorReadingStatus.CommunicationFailure;
                    }
                }
            }, null, TimeSpan.Zero, interval);
        }
    }

    public void StopPolling()
    {
        lock (_pollingLock)
        {
            _pollingTimer?.Change(Timeout.Infinite, 0);
        }
    }

    public static bool IsIntegratedGpuName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return false;

        // Discrete Intel Arc GPUs must not be classified as integrated
        if (name.Contains("Arc", StringComparison.OrdinalIgnoreCase) ||
            name.Contains("Iris Xe MAX", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        return name.Contains("Radeon(TM) Graphics", StringComparison.OrdinalIgnoreCase) ||
               name.Equals("AMD Radeon Graphics", StringComparison.OrdinalIgnoreCase) ||
               name.Equals("AMD Radeon(TM) Graphics", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Radeon 780M", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Radeon 760M", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Radeon 740M", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Radeon 680M", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Radeon 660M", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Radeon 890M", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Radeon 880M", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Radeon 610M", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Radeon Vega", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("UHD Graphics", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("HD Graphics", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Intel(R) UHD", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Intel(R) Iris", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Iris(R) Xe", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Iris Xe", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Iris Plus", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Iris Pro", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Intel(R) HD Graphics", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Intel(R) Graphics", StringComparison.OrdinalIgnoreCase) ||
               name.Equals("Intel Graphics", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("Adreno", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Selects the most representative real CPU temperature sensor without assuming one vendor's naming convention.
    /// AMD Ryzen sensors such as Core (Tctl/Tdie), CCDx (Tdie), and CCDs Max (Tdie) are explicitly recognized.
    /// Any other valid temperature sensor exposed by the CPU is retained as a last-resort real reading.
    /// </summary>
    public static int GetCpuTemperatureSensorPriority(string? sensorName)
    {
        if (string.IsNullOrWhiteSpace(sensorName)) return 0;

        if (sensorName.Contains("Tctl/Tdie", StringComparison.OrdinalIgnoreCase)) return 100;
        if (sensorName.Contains("CCDs Max", StringComparison.OrdinalIgnoreCase)) return 98;
        if (sensorName.Contains("Tdie", StringComparison.OrdinalIgnoreCase)) return 95;
        if (sensorName.Contains("Tctl", StringComparison.OrdinalIgnoreCase)) return 90;
        if (sensorName.Contains("Die", StringComparison.OrdinalIgnoreCase)) return 88;
        if (sensorName.Contains("Package", StringComparison.OrdinalIgnoreCase)) return 85;
        if (sensorName.Contains("CCD", StringComparison.OrdinalIgnoreCase) &&
            sensorName.Contains("Max", StringComparison.OrdinalIgnoreCase)) return 82;
        if (sensorName.Contains("CCD", StringComparison.OrdinalIgnoreCase)) return 78;
        if (sensorName.Contains("Core Max", StringComparison.OrdinalIgnoreCase)) return 74;
        if (sensorName.Contains("Core", StringComparison.OrdinalIgnoreCase)) return 68;
        if (sensorName.Contains("CPU", StringComparison.OrdinalIgnoreCase)) return 60;

        return 1;
    }

    private static void AddHardwareTree(IHardware hardware, List<IHardware> destination)
    {
        destination.Add(hardware);
        // Some CPU/GPU sensor groups are exposed as child hardware nodes by LHM.
        // Visit them explicitly; reading only the root node silently misses valid temperatures/clocks.
        foreach (var child in hardware.SubHardware)
            AddHardwareTree(child, destination);
    }

    private static int GetHardwarePriorityScore(IHardware hardware)
    {
        if (hardware.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel)
        {
            if (IsIntegratedGpuName(hardware.Name))
            {
                return 10; // iGPU processed after discrete GPUs
            }

            return 95; // All discrete GPUs across AMD, NVIDIA, and Intel Arc have equal priority
        }

        return hardware.HardwareType switch
        {
            HardwareType.Cpu => 90,
            HardwareType.Memory => 70,
            HardwareType.Motherboard => 60,
            HardwareType.Storage => 50,
            _ => 20
        };
    }

    public void Dispose()
    {
        lock (_pollingLock)
        {
            if (_disposed) return;
            _disposed = true;
            _pollingTimer?.Change(Timeout.Infinite, 0);
            _pollingTimer?.Dispose();
            _pollingTimer = null;
        }

        // Wait for an in-flight hardware read before closing LibreHardwareMonitor.
        _captureLock.Wait();
        try
        {
            _computer.Close();
        }
        catch
        {
            // Disposal must remain best-effort even if a hardware driver fails to close.
        }
        finally
        {
            _captureLock.Release();
        }
        GC.SuppressFinalize(this);
    }
}